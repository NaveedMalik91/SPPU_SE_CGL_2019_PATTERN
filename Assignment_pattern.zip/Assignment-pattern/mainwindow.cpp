#include "mainwindow.h"
#include "./ui_mainwindow.h"
QImage image(500,500,QImage::Format_RGB888);

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::dda(float x1,float y1, float x2, float y2)
{
    float dx,dy,length,x_inc,y_inc,x,y;
    dy=y2-y1;
    dx=x2-x1;
    if (abs(dy)>abs(dx))
        length=abs(dy);
    else
        length=abs(dx);

    x_inc=dx/length;
    y_inc=dy/length;

    x=x1;
    y=y1;

    int i=0;
    while(i<=length)
    {
        image.setPixel(x,y,qRgb(255,255,255));
        x=x+x_inc;
        y=y+y_inc;
        i++;
    }

    ui->label->setPixmap(QPixmap::fromImage(image));
}


void MainWindow::bcircle(int x3, int y3, int r)
{
    int x=0;
    int y=r;
    int d=3-(2*r);
    while(x<=y)
    {
        image.setPixel(x3+x,y3+y,qRgb(255,255,255));
        image.setPixel(x3-x,y3+y,qRgb(255,255,255));
        image.setPixel(x3+x,y3-y,qRgb(255,255,255));
        image.setPixel(x3-x,y3-y,qRgb(255,255,255));
        image.setPixel(x3+y,y3+x,qRgb(255,255,255));
        image.setPixel(x3+y,y3-x,qRgb(255,255,255));
        image.setPixel(x3-y,y3+x,qRgb(255,255,255));
        image.setPixel(x3-y,y3-x,qRgb(255,255,255));

        if (d<0)
            d=d+4*(x)+6;
        else
        {
            d=d+4*(x-y)+10;
            y=y-1;
        }
        x=x+1;
    }
    ui->label->setPixmap(QPixmap::fromImage(image));
}


void MainWindow::on_pushButton_clicked()
{
    dda(100,0,13.4,150);
    dda(13.4,150,186.6,150);
    dda(186.6,150,100,0);
    bcircle(100,100,100);
    bcircle(100,100,50);
}
