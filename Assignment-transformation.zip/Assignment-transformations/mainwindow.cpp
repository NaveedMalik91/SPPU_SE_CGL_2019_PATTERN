#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMouseEvent>
#include<QColorDialog>
#include <vector>
#include <iostream>
#include<math.h>

using namespace std;
static QColor color;
static QColor color1;
QImage img(400,400,QImage::Format_RGB888);
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

void MainWindow::dda_algo(int x1, int y1, int x2, int y2)
{
    color=qRgb(255,255,255);
    float dx,dy,len,xinc,yinc,x,y;
    dx=x2-x1;
    dy=y2-y1;
    if(abs(dx)>=abs(dy))
    {
        len=abs(dx);
    }
    else
    {
        len=abs(dy);
    }
    xinc=dx/len;
    yinc=dy/len;
    int sign;
    if(dx>0)
    {
        sign=+1;
    }
    else
    {
        sign=-1;
    }
    x=x1+0.5*(sign);
    y=y1+0.5*(sign);

    int i=0;
    while(i<len)
    {
        img.setPixel(int (x),int (y),color1.rgb());
        x+=xinc;
        y+=yinc;
        i++;
    }
    ui->label->setPixmap(QPixmap::fromImage(img));

}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::on_pushButton_clicked()
{
    dda_algo(0,200,400,200);
    dda_algo(200,0,200,400);
}
void MainWindow::on_pushButton_2_clicked()
{
    color1 = QColorDialog::getColor();
}
void MainWindow::on_pushButton_3_clicked()
{
    dda_algo(200,200,280,100);
    dda_algo(200,200,350,150);
    dda_algo(280,100,350,150);}




void MainWindow::translation(int tx,int ty){
    int x1=tx;
    int y1=ty;

    dda_algo(200+x1,200-y1,280+x1,100-y1);
    dda_algo(200+x1,200-y1,350+x1,150-y1);
    dda_algo(280+x1,100-y1,350+x1,150-y1);
}
void MainWindow::on_pushButton_4_clicked()
{
    int x1,y1;
    x1=ui->textEdit->toPlainText().toInt();
    y1=ui->textEdit_2->toPlainText().toInt();
    translation(x1,y1);

}



void MainWindow::rotation(){
    float d,t;
    d=ui->textEdit_3->toPlainText().toFloat();
    t=d/57.2958;
    float s=sin(t);
    float c=cos(t);
    float a=(-200*c-200*s+200);
    float b=200*s-200*c+200;
    //dda(x1,y1,x2,y2)
    dda_algo(200,200,(280*c+100*s+a),(-280*s+100*c+b));
    dda_algo(200,200,(350*c+150*s+a),(-350*s+150*c+b));
    dda_algo((280*c+100*s+a),(-280*s+100*c+b),(350*c+150*s+a),(-350*s+150*c+b));
}

void MainWindow::on_pushButton_5_clicked()
{
    rotation();
}



void MainWindow::scaling(){
    float x1,y1;
    x1=ui->textEdit_4->toPlainText().toFloat();
    y1=ui->textEdit_5->toPlainText().toFloat();
    float a=(-200*x1+200);
    float b=(-200*y1+200);
    dda_algo(200,200,280*x1+a,100*y1+b);
    dda_algo(200,200,350*x1+a,150*y1+b);
    dda_algo(280*x1+a,100*y1+b,350*x1+a,150*y1+b);
    // translation(200,200);
}
void MainWindow::on_pushButton_6_clicked()
{
    scaling();
}
